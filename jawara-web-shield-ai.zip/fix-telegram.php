<?php
/**
 * Quick Fix: Update Telegram Settings
 * Upload file ini ke folder plugin, lalu akses via browser
 * Setelah selesai, HAPUS file ini untuk keamanan
 */

// Load WordPress
require_once '../../../wp-load.php';

// Check admin
if ( ! current_user_can( 'manage_options' ) ) {
	die( 'Access Denied' );
}

// Update settings
update_option( 'jwsai_telegram_token', '8479382647:AAE7Y0yB83B5bbsakg9aLPbXIRRtwEGb2cU' );
update_option( 'jwsai_telegram_chat_id', '5570330814' );
update_option( 'jwsai_telegram_enabled', 1 );
update_option( 'jwsai_gemini_api_key', 'AIzaSyD9shWySoFhG6WayWMXcU9GsPV_LqQ5V9s' );

?>
<!DOCTYPE html>
<html>
<head>
	<title>Telegram Settings Updated</title>
	<style>
		body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
		.success { background: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 15px; border-radius: 5px; }
		.warning { background: #fff3cd; border: 1px solid #ffeaa7; color: #856404; padding: 15px; border-radius: 5px; margin-top: 20px; }
		code { background: #f4f4f4; padding: 2px 6px; border-radius: 3px; }
	</style>
</head>
<body>
	<h1>✅ Settings Updated Successfully!</h1>
	
	<div class="success">
		<h3>Telegram credentials have been updated:</h3>
		<ul>
			<li><strong>Bot Token:</strong> <?php echo esc_html( substr( get_option( 'jwsai_telegram_token' ), 0, 20 ) . '...' ); ?></li>
			<li><strong>Chat ID:</strong> <?php echo esc_html( get_option( 'jwsai_telegram_chat_id' ) ); ?></li>
			<li><strong>Enabled:</strong> <?php echo get_option( 'jwsai_telegram_enabled' ) ? 'Yes' : 'No'; ?></li>
		</ul>
	</div>

	<div class="warning">
		<h3>⚠️ IMPORTANT: Delete This File!</h3>
		<p>For security reasons, please <strong>DELETE</strong> this file immediately:</p>
		<code>/wp-content/plugins/jawara-web-shield-ai/fix-telegram.php</code>
		<p>Then go test Telegram connection in your WordPress admin.</p>
	</div>

	<p><a href="/wp-admin/admin.php?page=jawara-shield-ai&tab=settings">← Back to Plugin Settings</a></p>
</body>
</html>
