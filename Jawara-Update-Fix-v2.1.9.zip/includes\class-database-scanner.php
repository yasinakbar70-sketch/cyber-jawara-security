<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Jawara_Database_Scanner {
    // Stub class to prevent fatal errors
}
